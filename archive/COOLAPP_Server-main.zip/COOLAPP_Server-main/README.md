# COOLAPP Server

The backend for COOLAPP, a streaming app built for PRODYSGROUP.

iOS App: https://github.com/u4pak/COOLAPP
